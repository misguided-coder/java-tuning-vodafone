package com.example.memory.exercise._2;

public class ItemNotFoundException extends Exception {

	public ItemNotFoundException() {

	}

	public ItemNotFoundException(String message) {
		super(message);
	}
}
