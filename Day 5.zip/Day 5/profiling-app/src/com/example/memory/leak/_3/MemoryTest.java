package com.example.memory.leak._3;

import java.util.List;
import java.util.ArrayList;

public class MemoryTest {
    
    static List<Car> cars = new ArrayList<>();

    public static void main(String args[]) throws Exception{

        System.out.println("Starting the App");

	for(int i=0;i<2000000;i++){
		cars.add(new Car(100,"X1","BMW",1260000.00));
		Thread.sleep(50);
        	System.out.println("Adding Car object......");
	}
		
        System.out.println("Finished the App");
    }
}
