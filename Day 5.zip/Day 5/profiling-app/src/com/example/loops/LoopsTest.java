package com.example.loops;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LoopsTest {

	int N = 1000000;
	List<Integer> list = new ArrayList<>();

	public static void main(String[] s) {
		new LoopsTest();
	}

	public LoopsTest() {
		for (int i = 0; i < N; i++) {
			list.add(1000 + i);
		}

		new Thread(() -> {
			testForLoop();
		}).start();

		new Thread(() -> {
			testIterator();
		}).start();

		new Thread(() -> {
			testForEach();
		}).start();

		new Thread(() -> {
			testJava8StreamReduce();
		}).start();

		new Thread(() -> {
			testJava8ParallelStreamReduce();
		}).start();

	}

	public void testForLoop() {
		long total = 0;
		for (int i = 0; i < N; i++) {
			total = total + list.get(i);
		}
		System.out.println("For Loop Result : " + total);
	}

	public void testIterator() {
		long total = 0;
		Iterator<Integer> iterator = list.iterator();
		while (iterator.hasNext()) {
			total = total + iterator.next();
		}
		System.out.println("Iterator Result : " + total);
	}

	long forEachTotal = 0;

	public void testForEach() {
		list.forEach((value) -> {
			forEachTotal = forEachTotal + value;
		});
		System.out.println("For Each Result : " + forEachTotal);
	}

	public void testJava8StreamReduce() {
		long total = list.stream().reduce((accumulator, value) -> accumulator + value).get();
		System.out.println("Java 8 Streams Reduce Result : " + total);
	}
	
	
	public void testJava8ParallelStreamReduce() {
		long total = list.stream().parallel().reduce((accumulator, value) -> accumulator + value).get();
		System.out.println("Java 8 Parallel Streams Reduce Result : " + total);
	}
	
	

}