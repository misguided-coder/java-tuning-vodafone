package com.example.control.structures;

public class ConditionsTest {

	String color = "Blue";

	int N = 200000;

	public static void main(String[] s) {
		new ConditionsTest();
	}

	public ConditionsTest() {
		new Thread(() -> {
			for (int i = 0; i < N; i++) {
				testIf();
			}
		}).start();

		new Thread(() -> {
			for (int i = 0; i < N; i++) {
				testSwitch();
			}
		}).start();

	}

	public void testIf() {

		if (color.equals("Black")) {
			System.out.println("I am Black");
		} else if (color.equals("Blue")) {
			System.out.println("I am Blue");
		} else if (color.equals("Yellow")) {
			System.out.println("I am Yellow");
		} else if (color.equals("Green")) {
			System.out.println("I am Green");
		} else {
			System.out.println("I am just a Color");
		}

	}


	public void testSwitch() {

		switch (color) {
		case "Black":
			System.out.println("I am Black");
			break;
		case "Blue":
			System.out.println("I am Blue");
			break;
		case "Yellow":
			System.out.println("I am Yellow");
			break;
		case "Green":
			System.out.println("I am Green");
			break;
		default:
			System.out.println("I am just a Color");
		}
	}
}