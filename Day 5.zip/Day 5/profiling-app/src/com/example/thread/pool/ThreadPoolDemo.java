package com.example.thread.pool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolDemo {
	
	public static void main(String[] args) {
		UC1();
		UC2();
	}


	static void UC1() {
		
		for (int i = 0; i < 100; i++) {
			Runnable task = new PrintTask();
			new Thread(task).start();
		}
	}

	static void UC2() {
	
		ExecutorService pool = Executors.newFixedThreadPool(10);
		
		for (int i = 0; i < 100; i++) {
			Runnable task = new PrintTask();
			pool.execute(task);
		}
		// This will make the executor accept no new threads
		// and finish all existing threads in the queue
		//pool.shutdown();
		// Wait until all threads are finish
		//while (!pool.isTerminated()) {
	
		//}
		//System.out.println("Finished all threads");
	}
}


class PrintTask implements Runnable {
	
	@Override
	public void run() {
		for (int i = 1; i < 10; i++) {
			System.out.println("Printing ..."+i);
		}
	}
}
